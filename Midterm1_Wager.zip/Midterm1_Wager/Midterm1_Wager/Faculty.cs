﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm1_Wager
{
    public class Faculty
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Position { get; set; }

        public Faculty()
        {
            FirstName = "";
            LastName = "";
            Position = "";
        }

        public Faculty(string theFirstName, string theLastname, string thePosition)
        {
            this.FirstName = theFirstName;
            this.LastName = theLastname;
            this.Position = thePosition;
        }
    }
}
