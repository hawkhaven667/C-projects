﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm1_Wager
{
    public partial class Main : Form
    {
        public static List<Department> DepartmentList = new List<Department>();
        int currentIndex = 0;
        
        public Main()
        {
            InitializeComponent();
        }
       
        private void Main_Load(object sender, EventArgs e)
        {
            Department Department1 = new Department();
            DepartmentList.Add(Department1);
            Department1.Name = "IT"; Department1.Building = "Shelby Hall"; Department1.College = "School of Computing;";
            Faculty Faculty1 = new Faculty();
            Department1.FacultyList.Add(Faculty1);
            Faculty1.FirstName = "Ocllo"; Faculty1.LastName = "Robinson"; Faculty1.Position = "Instructor";
            Faculty Faculty2 = new Faculty();
            Department1.FacultyList.Add(Faculty2);
            Faculty2.FirstName = "Leo"; Faculty2.LastName = "Denton"; Faculty2.Position = "Instructor";

            Department Department2 = new Department();
            DepartmentList.Add(Department2);
            Department2.Name = "CS"; Department2.Building = "Shelby Hall"; Department2.College = "School of computing";
            Faculty Faculty3 = new Faculty();
            Department2.FacultyList.Add(Faculty3);
            Faculty3.FirstName = "Ryan"; Faculty3.LastName = "Benton"; Faculty3.Position = "Assistant Professor";
            Faculty Faculty4 = new Faculty();
            Department2.FacultyList.Add(Faculty4);
            Faculty4.FirstName = "Vickie"; Faculty4.LastName = "Speed"; Faculty4.Position = "Academic Records Specialist";

            Department Department3 = new Department();
            DepartmentList.Add(Department3);
            Department3.Name = "EE"; Department3.Building = "Shelby Hall"; Department3.College = "College of Engineering";
            Faculty Faculty5 = new Faculty();
            Department3.FacultyList.Add(Faculty5);
            Faculty5.FirstName = "Samuel"; Faculty5.LastName = "Russ"; Faculty5.Position = "Associate Professor";
            Faculty Faculty6 = new Faculty();
            Department3.FacultyList.Add(Faculty6);
            Faculty6.FirstName = "Alani"; Faculty6.LastName = "Rodgers"; Faculty6.Position = "Secretary";

            updateGUI();
        }

        public void updateGUI()
        {
            bool isEmpty = !DepartmentList.Any();
            listBox1.Items.Clear();

            if (isEmpty)
            {
                MessageBox.Show("No Departments Exist", "Error");
                txtName.Clear();
                txtSchool.Clear();
                txtBuilding.Clear();
            }

            else
            {
                txtName.Text = DepartmentList[currentIndex].Name;
                txtBuilding.Text = DepartmentList[currentIndex].Building;
                txtSchool.Text = DepartmentList[currentIndex].College;
                string listFaculty = "";
                foreach (Faculty d in DepartmentList[currentIndex].FacultyList)
                {
                    listFaculty = d.FirstName.ToString() + " " + d.LastName.ToString() + " " + d.Position.ToString();
                    listBox1.Items.Add(listFaculty);
                }
            }
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Random randNum = new Random();
            int Min = 0;
            int Max = DepartmentList.Count;
            int Check = currentIndex;
            int New = randNum.Next(Min, Max);

            while (New == Check)
            {
                New = randNum.Next(Min, Max);
            }

            currentIndex = New;
            updateGUI();
        }

        private void btnSaveDep_Click(object sender, EventArgs e)
        {
            DepartmentList[currentIndex].Name = txtName.Text;
            DepartmentList[currentIndex].Building = txtBuilding.Text;
            DepartmentList[currentIndex].College = txtSchool.Text;
        }

        private void btnDeleteDep_Click(object sender, EventArgs e)
        {
            
            if (DepartmentList.ElementAtOrDefault(currentIndex) != null)
            {
                DepartmentList.RemoveAt(currentIndex);
            }

            currentIndex = 0;

            updateGUI();
        }

        private void btnAddDep_Click(object sender, EventArgs e)
        {
            Form f1 = new Form1();
            if (f1.ShowDialog() == DialogResult.OK)
            {
                DepartmentList.Add((Department)f1.Tag);
                currentIndex = DepartmentList.Count - 1;
                updateGUI();

            }
            


        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            if (DepartmentList.Any(a => a.Name == txtSearch.Text.ToUpper()))
            {
                int Search = DepartmentList.FindIndex(a => a.Name.ToUpper().Contains(txtSearch.Text.ToUpper()));

                currentIndex = Search;
            }
            else
            {
                MessageBox.Show("No Departments Match", "Error");
            }
                updateGUI();
            

        }

        private void btnAddFac_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            if (f2.ShowDialog() == DialogResult.OK)
            {
                DepartmentList[currentIndex].FacultyList.Add((Faculty)f2.Tag);
                updateGUI();
            }
            
            

        }

        private void btnDeleteFac_Click(object sender, EventArgs e)
        {
           
            
                if (listBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Please Select A Faculty Member", "Error");
                }
                else 
                {
                    DepartmentList[currentIndex].FacultyList.RemoveAt(listBox1.SelectedIndex);
                    updateGUI();
                }
            

        }
    }
}
