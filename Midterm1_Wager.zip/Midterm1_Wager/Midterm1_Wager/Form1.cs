﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm1_Wager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if (txtBuilding.Text != "" | txtName.Text != "" | txtSchool.Text != "")
            {
                Department newDepartment = new Department();
                newDepartment.Name = txtName.Text;
                newDepartment.Building = txtBuilding.Text;
                newDepartment.College = txtSchool.Text;
                Tag = newDepartment;
            }
          else
            {
                Tag = null;
            }
            
        }
    }
}
