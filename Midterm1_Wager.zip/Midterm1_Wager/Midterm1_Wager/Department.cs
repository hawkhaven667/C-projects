﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm1_Wager
{
    public class Department
    {
        public string Name { get; set; }
        public string Building { get; set; }
        public string College { get; set; }
        public List<Faculty> FacultyList { get; set; }

        public Department()
        {
            FacultyList = new List<Faculty>();
            Name = "";
            Building = "";
            College = "";
            

        }

        public Department(string theName, string theBuilding, string theCollege, List<Faculty> theList)
        {
            this.Name = theName;
            this.Building = theBuilding;
            this.College = theCollege;
            this.FacultyList = theList;
        }

    }

}