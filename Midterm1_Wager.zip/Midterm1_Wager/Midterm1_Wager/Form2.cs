﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm1_Wager
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtFirst.Text != "" | txtLast.Text != "" | txtPosition.Text != "")
            {
                Faculty newFaculty = new Faculty();
                newFaculty.FirstName = txtFirst.Text;
                newFaculty.LastName = txtLast.Text;
                newFaculty.Position = txtPosition.Text;
                Tag = newFaculty;
            }          
           else
            {
                MessageBox.Show("Fill All Fields", "Error");
            }
            }
        }
    }

