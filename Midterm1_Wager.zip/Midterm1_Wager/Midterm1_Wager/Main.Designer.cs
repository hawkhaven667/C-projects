﻿namespace Midterm1_Wager
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtBuilding = new System.Windows.Forms.TextBox();
            this.txtSchool = new System.Windows.Forms.TextBox();
            this.btnSaveDep = new System.Windows.Forms.Button();
            this.btnDeleteDep = new System.Windows.Forms.Button();
            this.btnAddDep = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnAddFac = new System.Windows.Forms.Button();
            this.btnDeleteFac = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(15, 22);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(122, 20);
            this.txtSearch.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(13, 48);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(124, 36);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search for Department";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(154, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Or";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(199, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 62);
            this.button2.TabIndex = 3;
            this.button2.Text = "Show Random Department";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Building";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "School";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(61, 95);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(224, 20);
            this.txtName.TabIndex = 7;
            // 
            // txtBuilding
            // 
            this.txtBuilding.Location = new System.Drawing.Point(61, 128);
            this.txtBuilding.Name = "txtBuilding";
            this.txtBuilding.Size = new System.Drawing.Size(224, 20);
            this.txtBuilding.TabIndex = 8;
            // 
            // txtSchool
            // 
            this.txtSchool.Location = new System.Drawing.Point(61, 161);
            this.txtSchool.Name = "txtSchool";
            this.txtSchool.Size = new System.Drawing.Size(224, 20);
            this.txtSchool.TabIndex = 9;
            // 
            // btnSaveDep
            // 
            this.btnSaveDep.Location = new System.Drawing.Point(15, 187);
            this.btnSaveDep.Name = "btnSaveDep";
            this.btnSaveDep.Size = new System.Drawing.Size(75, 50);
            this.btnSaveDep.TabIndex = 10;
            this.btnSaveDep.Text = "Save Department Changes";
            this.btnSaveDep.UseVisualStyleBackColor = true;
            this.btnSaveDep.Click += new System.EventHandler(this.btnSaveDep_Click);
            // 
            // btnDeleteDep
            // 
            this.btnDeleteDep.Location = new System.Drawing.Point(113, 187);
            this.btnDeleteDep.Name = "btnDeleteDep";
            this.btnDeleteDep.Size = new System.Drawing.Size(75, 50);
            this.btnDeleteDep.TabIndex = 11;
            this.btnDeleteDep.Text = "Delete Department";
            this.btnDeleteDep.UseVisualStyleBackColor = true;
            this.btnDeleteDep.Click += new System.EventHandler(this.btnDeleteDep_Click);
            // 
            // btnAddDep
            // 
            this.btnAddDep.Location = new System.Drawing.Point(210, 187);
            this.btnAddDep.Name = "btnAddDep";
            this.btnAddDep.Size = new System.Drawing.Size(75, 50);
            this.btnAddDep.TabIndex = 12;
            this.btnAddDep.Text = "Add Department";
            this.btnAddDep.UseVisualStyleBackColor = true;
            this.btnAddDep.Click += new System.EventHandler(this.btnAddDep_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(15, 243);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(270, 95);
            this.listBox1.TabIndex = 13;
            // 
            // btnAddFac
            // 
            this.btnAddFac.Location = new System.Drawing.Point(27, 344);
            this.btnAddFac.Name = "btnAddFac";
            this.btnAddFac.Size = new System.Drawing.Size(89, 23);
            this.btnAddFac.TabIndex = 14;
            this.btnAddFac.Text = "Add Faculty";
            this.btnAddFac.UseVisualStyleBackColor = true;
            this.btnAddFac.Click += new System.EventHandler(this.btnAddFac_Click);
            // 
            // btnDeleteFac
            // 
            this.btnDeleteFac.Location = new System.Drawing.Point(174, 344);
            this.btnDeleteFac.Name = "btnDeleteFac";
            this.btnDeleteFac.Size = new System.Drawing.Size(89, 23);
            this.btnDeleteFac.TabIndex = 15;
            this.btnDeleteFac.Text = "Delete Faculty";
            this.btnDeleteFac.UseVisualStyleBackColor = true;
            this.btnDeleteFac.Click += new System.EventHandler(this.btnDeleteFac_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDeleteFac);
            this.Controls.Add(this.btnAddFac);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btnAddDep);
            this.Controls.Add(this.btnDeleteDep);
            this.Controls.Add(this.btnSaveDep);
            this.Controls.Add(this.txtSchool);
            this.Controls.Add(this.txtBuilding);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Name = "Main";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtBuilding;
        private System.Windows.Forms.TextBox txtSchool;
        private System.Windows.Forms.Button btnSaveDep;
        private System.Windows.Forms.Button btnDeleteDep;
        private System.Windows.Forms.Button btnAddDep;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnAddFac;
        private System.Windows.Forms.Button btnDeleteFac;
    }
}

