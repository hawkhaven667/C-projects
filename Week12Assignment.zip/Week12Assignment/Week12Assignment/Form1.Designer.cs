﻿namespace Week12Assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstStars = new System.Windows.Forms.ListBox();
            this.lstPlanet = new System.Windows.Forms.ListBox();
            this.lstMoon = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstStars
            // 
            this.lstStars.FormattingEnabled = true;
            this.lstStars.Location = new System.Drawing.Point(12, 36);
            this.lstStars.Name = "lstStars";
            this.lstStars.Size = new System.Drawing.Size(120, 160);
            this.lstStars.TabIndex = 0;
            this.lstStars.SelectedIndexChanged += new System.EventHandler(this.lstStars_SelectedIndexChanged);
            // 
            // lstPlanet
            // 
            this.lstPlanet.FormattingEnabled = true;
            this.lstPlanet.Location = new System.Drawing.Point(138, 36);
            this.lstPlanet.Name = "lstPlanet";
            this.lstPlanet.Size = new System.Drawing.Size(120, 160);
            this.lstPlanet.TabIndex = 1;
            this.lstPlanet.SelectedIndexChanged += new System.EventHandler(this.lstPlanet_SelectedIndexChanged);
            // 
            // lstMoon
            // 
            this.lstMoon.FormattingEnabled = true;
            this.lstMoon.Location = new System.Drawing.Point(264, 36);
            this.lstMoon.Name = "lstMoon";
            this.lstMoon.Size = new System.Drawing.Size(120, 160);
            this.lstMoon.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Stars";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Planets";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(264, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Moons";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(138, 218);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(120, 53);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstMoon);
            this.Controls.Add(this.lstPlanet);
            this.Controls.Add(this.lstStars);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstStars;
        private System.Windows.Forms.ListBox lstPlanet;
        private System.Windows.Forms.ListBox lstMoon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRefresh;
    }
}

