﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week12Assignment
{
    public partial class Form1 : Form
    {
        Galaxy1Entities context = new Galaxy1Entities();
        public Form1()
        {
            InitializeComponent();
            UpdateForm();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void UpdateForm()
        {
            lstStars.Items.Clear();
            lstPlanet.Items.Clear();
            lstMoon.Items.Clear();
            List<Star> starList = context.Stars.ToList();
            List<Planet> planetList = context.Planets.ToList();
            List<Moon> moonList = context.Moons.ToList();
            ArrayList list = new ArrayList();
            foreach (Star currentStar in starList)               
            {
                lstStars.Items.Add(currentStar.Name);
                
            }
            lstStars.Sorted = true;
            foreach (Planet currentPlanet in planetList)
            {
                lstPlanet.Items.Add(currentPlanet.Name);
            }
            lstPlanet.Sorted = true;
            foreach (Moon currentMoon in moonList)
            {
                list.Add(currentMoon.MoonName);
            }
            list.Sort();
            list.Reverse();
            foreach (var item in list)
            {
                lstMoon.Items.Add(item);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            UpdateForm();
        }

        private void lstStars_SelectedIndexChanged(object sender, EventArgs e)
        {
            string starName = lstStars.Text;
            lstPlanet.Items.Clear();
            lstMoon.Items.Clear();
            List<Star> starList = context.Stars.ToList();
            Star currentStar = starList.FirstOrDefault(Star => Star.Name == starName);
            int startID = currentStar.StarID;

            List<Planet> starToPlanet = context.Planets.Where(x => x.StarID == startID).ToList();

            foreach (Planet currentPlanet in starToPlanet)
            {
                lstPlanet.Items.Add(currentPlanet.Name);
            }
        }

        private void lstPlanet_SelectedIndexChanged(object sender, EventArgs e)
        {
            string planetName = lstPlanet.Text;
            lstMoon.Items.Clear();
            List<Planet> planetList = context.Planets.ToList();
            Planet currentPlanet = planetList.FirstOrDefault(Planet => Planet.Name == planetName);

            int planetId = currentPlanet.PlanetID;

            List<Moon> moonToPlanet = context.Moons.Where(x => x.PlanetID == planetId).ToList();

            foreach (Moon currentMoon in moonToPlanet)
            {
                lstMoon.Items.Add(currentMoon.MoonName);
            }
        }
    }
}
