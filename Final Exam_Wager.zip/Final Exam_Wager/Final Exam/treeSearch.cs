﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Exam
{
    public partial class treeSearch : Form
    {
        TreesEntities context = new TreesEntities();
        public treeSearch()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            decimal price;
            try
            {
                price = System.Convert.ToDecimal(txtSearch.Text);
                
            }
            catch
            {
                MessageBox.Show("Must enter a decimal number for price");
                return;
            }
            List<Tree> searchList = context.Trees.Where(x => x.Price == price || x.Price <= price ).ToList();

            foreach (Tree currentTree in searchList)
            {
                listBox1.Items.Add(currentTree.TreeType + ":" + " " + currentTree.Price);
            }    
        }

        private void btnName_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string search;
            search = txtSearch.Text;
            List<Tree> searchList = context.Trees.ToList();
            var result = searchList.Select(x => x.TreeType.ToUpper());
            foreach (Tree currentTree in searchList.Where(x => x.TreeType.ToUpper().Contains(search.ToUpper())))
            {
                
                listBox1.Items.Add(currentTree.TreeType + ":" + " " + currentTree.Price);
            }
        }
    }
}
