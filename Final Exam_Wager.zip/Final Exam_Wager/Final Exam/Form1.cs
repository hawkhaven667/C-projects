﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Exam
{
    public partial class Form1 : Form
    {
        TreesEntities context = new TreesEntities();
        public Form1()
        {
            InitializeComponent();
            UpdateForm();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            Tree selectedTree = (Tree)listBox1.SelectedItem;
            txtHeight.Text = selectedTree.Height.ToString();
            txtPrice.Text = selectedTree.Price.ToString();
            txtQuantity.Text = selectedTree.Quantity.ToString();
            txtType.Text = selectedTree.TreeType;
            txtID.Text = selectedTree.TreeID.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Tree selectedTree = (Tree)listBox1.SelectedItem;
            Tree treeToUpdate = context.Trees.FirstOrDefault(x => x.TreeID == selectedTree.TreeID);
            int quantity, height;
            decimal price;
            try
            {
                quantity = System.Convert.ToInt32(txtQuantity.Text);
                treeToUpdate.Quantity = quantity;

            }
            catch
            {
                MessageBox.Show("Must enter numeric value for quantity");
                return;
            }
            try
            {
                height = System.Convert.ToInt32(txtHeight.Text);
                treeToUpdate.Height = height;
            }
            catch
            {
                MessageBox.Show("Must eneter a numeric value for height");
                return;
            }
            try
            {
                price = System.Convert.ToDecimal(txtPrice.Text);
                treeToUpdate.Price = price;
            }
            catch
            {
                MessageBox.Show("Must enter a decimal number for price");
                return;
            }
            treeToUpdate.TreeType = txtType.Text;
            context.SaveChanges();
            UpdateForm();

        }
        private void UpdateForm()
        {
            List<Tree> treeList = context.Trees.OrderBy(x => x.TreeType).ToList();
            listBox1.DataSource = treeList;
            listBox1.DisplayMember = "TreeType";
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Form deleteForm = new Delete();
            if(deleteForm.ShowDialog() == DialogResult.OK)
            {
                Tree selectedTree = (Tree)listBox1.SelectedItem;
                context.Trees.Remove(selectedTree);
                context.SaveChanges();
                UpdateForm();

            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form AddTrees = new addTree();
            if (AddTrees.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    context.Trees.Add((Tree)AddTrees.Tag);
                    context.SaveChanges();
                }
                catch
                {
                    MessageBox.Show("data validation error");
                        return;

                }
            }
            UpdateForm();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Form TreeSearch = new treeSearch();
            TreeSearch.Show();
        }
    }
}
