﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Exam
{
    public partial class addTree : Form
    {
        TreesEntities context = new TreesEntities();
        public addTree()
        {
            InitializeComponent();
        }

        private void addTree_Load(object sender, EventArgs e)

        {
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int quantity, height;
            decimal price;
            Tree addTree = new Tree();
            {
                try
                {
                    quantity = System.Convert.ToInt32(txtQuantity.Text);
                    addTree.Quantity = quantity;
                }
                catch
                {
                    MessageBox.Show("Must enter numeric value for quantity");
                    return;
                }
                try
                {
                    height = System.Convert.ToInt32(txtHeight.Text);
                    addTree.Height = height;
                }
                catch
                {
                    MessageBox.Show("Must enter a numeric value for height");
                    return;
                }
                try
                {
                    price = System.Convert.ToDecimal(txtPrice.Text);
                    addTree.Price = price;
                }
                catch
                {
                    MessageBox.Show("Must enter a decimal number for price");
                    return;
                }
                addTree.TreeType = txtType.Text;
                Tag = addTree;
                this.DialogResult = DialogResult.OK;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
